//
//  VistaCellPhoto.m
//  IHPlus
//
//  Created by Polina Koronkevich on 4/5/12.
//  Copyright (c) 2012 ecoarttech. All rights reserved.
//

#import "VistaCellPhoto.h"

@implementation VistaCellPhoto

@synthesize photo;

@end
