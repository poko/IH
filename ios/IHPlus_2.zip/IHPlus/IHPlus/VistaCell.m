//
//  VistaCell.m
//  IHPlus
//
//  Created by Polina Koronkevich on 4/5/12.
//  Copyright (c) 2012 ecoarttech. All rights reserved.
//

#import "VistaCell.h"

@implementation VistaCell

@synthesize vistaNum, prompt;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
