//
//  VistaCellPhoto.h
//  IHPlus
//
//  Created by Polina Koronkevich on 4/5/12.
//  Copyright (c) 2012 ecoarttech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VistaCell.h"

@interface VistaCellPhoto : VistaCell

@property (nonatomic, strong) IBOutlet UIImageView *photo;

@end
