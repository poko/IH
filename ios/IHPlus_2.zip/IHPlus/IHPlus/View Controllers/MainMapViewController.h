//
//  MainMapViewController.h
//  IHPlus
//
//  Created by Polina Koronkevich on 4/25/12.
//  Copyright (c) 2012 ecoarttech. All rights reserved.
//

#import "MapViewController.h"

@interface MainMapViewController : MapViewController{
//    NSMutableArray *_monitoredRegions;
}

-(void)rewalkHike:(NSString *) hikeId;

@end
