//
//  Constants.m
//  IHPlus
//
//  Created by Polina Koronkevich on 4/26/12.
//  Copyright (c) 2012ecoarttech. All rights reserved.
//

#import "Constants.h"

@implementation Constants

@end
