//
//  ImageLoader.h
//  IHPlus
//
//  Created by Polina Koronkevich on 4/12/12.
//  Copyright (c) 2012 ecoarttech. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ImageLoader : NSObject

+(UIImage *) getImageForUrl:(NSString *) url;

@end
