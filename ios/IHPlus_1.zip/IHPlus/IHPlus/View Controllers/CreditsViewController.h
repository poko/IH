//
//  CreditsViewController.h
//  IHPlus
//
//  Created by Polina Koronkevich on 3/16/12.
//  Copyright (c) 2012 ecoarttech. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CreditsViewController : UIViewController

@property (nonatomic, strong) IBOutlet UITextView *textview;
- (IBAction)done:(id)sender;

@end
