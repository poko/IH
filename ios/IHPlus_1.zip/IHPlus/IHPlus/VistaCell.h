//
//  VistaCell.h
//  IHPlus
//
//  Created by Polina Koronkevich on 4/5/12.
//  Copyright (c) 2012 ecoarttech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VistaCell : UITableViewCell

@property (nonatomic, strong) IBOutlet UILabel *vistaNum;
@property (nonatomic, strong) IBOutlet UILabel *prompt;

@end
